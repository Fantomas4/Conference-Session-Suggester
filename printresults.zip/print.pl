%Print the Titles with the corresponding Score for each Season.
printList( [ ] , [ ] ) .
printList( [ X | Titles ] , [ Y | Srscore ] ) :- write("Sesion:"), write( X ), nl, write( "Relevance =" ), write( Y ), nl,
    printList( Titles , Srscore ) .
