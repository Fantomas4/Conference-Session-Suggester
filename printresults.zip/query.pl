% test with: query([day-4,'general results'-1,exceptions,airplane-1,'election vote','general meeting'-2]).

% Import calculateScore.pl
:- [calculateScore].

% Import sort.pl
:- [sort].

% Import facts about sessions, and respective topics from sessions.pl
:- [sessions].

% Import print.pl
:- [print].


	
:- insersionSort(Score,Srscore).
:- printList (Titles,Srscore).

