%Print the Titles with the corresponding Score for each Season.
printList( [ ] , [ ] ) .
printList( [ X | Titles ] , [ Y | Score ] ) :- write( X ) , write( Y ), nl,
    printList( Titles , Score ) .
