%Sort List Score with descending order with Insertion Sort.
insertionSort( [ ] , [ ] ) .
insertionSort( [ H | T ] , R ) :-  insertionSort( T | TR ) ,
    put( H , TR , R ).
put( H , [ ] , [ H ] ) :- ! .
put( H , [ X | Y ] , [ H , X | Y ] ) :- H>X, ! .
put( H , [ X | Y ] , [ X | Z ] ) :-
    put( H , Y , Z ),! .


